export default function Header() {
  return <header><h2>Header</h2></header>;
}
