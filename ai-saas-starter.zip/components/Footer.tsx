export default function Footer() {
  return <footer><p>Footer</p></footer>;
}
