export default function Home() {
  return (
    <main>
      <h1>AI Website Starter</h1>
      <p>Your site is ready.</p>
    </main>
  );
}
